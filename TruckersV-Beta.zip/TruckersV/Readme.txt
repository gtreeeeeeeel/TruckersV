Truckers V - Beta
Developed by Reeeeeeeel

Bored of playing GTA V? Well this script mod is for you. 

Truckers V is an immersive truck delivery script mod for GTA V that lets players experience the life of a trucker, taking on dynamic delivery jobs across Los Santos and Blaine County, transporting goods to a variety of locations, from bustling city warehouses to remote mountain depots. Truckers V brings a new level of depth to the world of GTA V. 

KEY FEATURES

DYNAMICS DELIVERY JOBS
Start jobs from the Truck Depot and choose from a selection of randomized delivery locations across Los Santos and Blaine County.

INTERACTIVE MENU
Freely select your delivery location using LemonUI, with rewards ranging from $5,000 to $12,000, depending on distance and difficulty.

REWARDS
Each delivery comes with a reward, automatically added to your balance upon delivery confirmation.

IMMERSIVE GAMEPLAY
Trucks spawn at the depot and feature a blip system where can track your truck, job site, and delivery point.
Fail a job if your truck is destroyed, flipped, get arrested and wasted.

DELIVERY LOCATIONS
Deliver to various spots, from the bustling Downtown Warehouse to remote outposts like Mount Chiliad. Every job feels fresh and unpredictable!

KEY BINDINGS (Can be changed in .ini file)
Start Job: T
Confirm Delivery: Y

REPORT ISSUE AND SUGGESTIONS
GitHub

REQUIRMENTS

GTA V
ScriptHookV
ScriptHookVDotNet
LemonUI

Ensure you’ve got a scripts folder set up in your GTA V directory

INSTALLATION

1. Extract TruckersV
2. Place TruckersV.dll and TruckersV.ini into scripts folder.
3. Make sure all the required mods are installed.
4. Launch GTA V, head to the Truck Depot (marked on your map), and start delivering!

CHANGELOGS

v1.0 — Beta
This script mod is beta. Report issues and bugs and suggest future feature in GitHub. 
